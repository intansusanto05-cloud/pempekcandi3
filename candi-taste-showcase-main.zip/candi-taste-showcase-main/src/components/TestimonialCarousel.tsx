import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

const testimonials = [
  {
    id: 1,
    name: "Udin",
    role: "New Customer",
    content: "Pempek Candi brings back memories of authentic Palembang flavors. The cuko sauce is perfectly balanced, and the fish cakes are always fresh. Best pempek in town!",
    rating: 5,
  },
  {
    id: 2,
    name: "Farah",
    role: "Reseller",
    content: "We've been ordering from Pempek Candi for our customer for over a year. Consistent quality, reliable delivery, and their customers love it. Highly recommended!",
    rating: 5,
  },
  {
    id: 3,
    name: "Tya",
    role: "Regular Customer",
    content: "Finally found authentic pempek that tastes like home! The variety is amazing and the prices are very reasonable. My family orders from them every week now.",
    rating: 5,
  },
  {
    id: 4,
    name: "Salmi",
    role: "Food Blogger",
    content: "As someone who reviews Indonesian cuisine regularly, Pempek Candi stands out for their commitment to traditional recipes while maintaining modern food safety standards.",
    rating: 5,
  },
];

const TestimonialCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const goToNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const goToPrevious = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToSlide = (index: number) => {
    setIsAutoPlaying(false);
    setCurrentIndex(index);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <div className="relative max-w-4xl mx-auto">
      <Card className="shadow-strong">
        <CardContent className="p-8 md:p-12">
          <div className="flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
              <span className="text-3xl font-bold text-primary">
                {currentTestimonial.name.charAt(0)}
              </span>
            </div>

            <div className="flex gap-1 mb-6">
              {[...Array(currentTestimonial.rating)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-accent text-accent" />
              ))}
            </div>

            <p className="text-lg md:text-xl text-foreground/90 mb-6 leading-relaxed italic">
              "{currentTestimonial.content}"
            </p>

            <div>
              <p className="font-bold text-lg text-foreground">{currentTestimonial.name}</p>
              <p className="text-muted-foreground">{currentTestimonial.role}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-center gap-4 mt-8">
        <Button
          variant="outline"
          size="icon"
          onClick={goToPrevious}
          className="rounded-full"
          aria-label="Previous testimonial"
        >
          <ChevronLeft className="w-5 h-5" />
        </Button>

        <div className="flex gap-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === currentIndex ? "bg-primary w-8" : "bg-border hover:bg-primary/50"
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>

        <Button
          variant="outline"
          size="icon"
          onClick={goToNext}
          className="rounded-full"
          aria-label="Next testimonial"
        >
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};

export default TestimonialCarousel;
